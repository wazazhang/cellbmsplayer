package de.jarnbjo.theora;

public class Coordinate extends MotionVector {
}