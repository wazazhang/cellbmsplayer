/*
 * $ProjectName$
 * $ProjectRevision$
 * -----------------------------------------------------------
 * $Id: SeekPoint.java,v 1.1 2003/03/03 21:53:17 jarnbjo Exp $
 * -----------------------------------------------------------
 *
 * $Author: jarnbjo $
 *
 * Description:
 *
 * Copyright 2002-2003 Tor-Einar Jarnbjo
 * -----------------------------------------------------------
 *
 * Change History
 * -----------------------------------------------------------
 * $Log: SeekPoint.java,v $
 * Revision 1.1  2003/03/03 21:53:17  jarnbjo
 * no message
 *
 */

package de.jarnbjo.flac;

public class SeekPoint {

   private long sampleNumber, offset;
   private int numberOfSamples;

   public SeekPoint(long sampleNumber, long offset, int numberOfSamples) {
      this.sampleNumber=sampleNumber;
      this.offset=offset;
      this.numberOfSamples=numberOfSamples;
   }

}