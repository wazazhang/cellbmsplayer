package de.jarnbjo.theora;

public class CoeffNode {
   public int i;
   public CoeffNode next;
}